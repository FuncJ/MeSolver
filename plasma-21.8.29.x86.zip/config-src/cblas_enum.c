
#include <stdio.h>

#ifdef HAVE_MKL
    #include <mkl_cblas.h>
#else
    #include <cblas.h>
#endif

#ifdef CBLAS_ADD_TYPEDEF
typedef enum CBLAS_TRANSPOSE CBLAS_TRANSPOSE;
#endif

int main( int argc, char** argv )
{
    CBLAS_TRANSPOSE trans;
    printf( "CBLAS_TRANSPOSE ok\n" );
    return 0;
}

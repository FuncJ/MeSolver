
#include <stdio.h>

#ifdef HAVE_MKL
    #include <mkl_lapacke.h>
#else
    #include <lapacke.h>
#endif

int main( int argc, char** argv )
{
    int i, m = 4, n = 3, info = 0;
    double A[4*3] = { 1, 2, 3, 4,    5,  6,  7,  8,    9, 10, 11, 12 };
    double D[4*3] = { 2, 4, 6, 8,   10, 12, 14, 16,   18, 20, 22, 24 };
    info = LAPACKE_dlascl_work( LAPACK_COL_MAJOR, 'g', -1, -1, 1.0, 2.0, m, n, A, m );
    if (info != 0) {
        printf( "dlascl failed: info %d\n", info );
        return 1;
    }
    for (i = 0; i < m*n; ++i) {
        if (A[i] != D[i]) {
            printf( "dlascl failed: A[%d] %.2f != D[%d] %.2f\n",
                    i, A[i], i, D[i] );
            return 1;
        }
    }
    printf( "dlascl ok\n" );
    return 0;
}

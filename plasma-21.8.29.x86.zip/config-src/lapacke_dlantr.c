
#include <stdio.h>

#ifdef HAVE_MKL
    #include <mkl_lapacke.h>
#else
    #include <lapacke.h>
#endif

int main( int argc, char** argv )
{
    int n = 3;
    double A[3*3] = { 1, 2, 3,   4, 5, 6,   7, 8, 9 };
    double work[1];
    double expect = 11;
    double result = LAPACKE_dlantr_work( LAPACK_COL_MAJOR, '1', 'L', 'N', n, n, A, n, work );
    int okay = (result == expect);
    printf( "dlantr result %.2f, expect %.2f, %s\n",
            result, expect, (okay ? "ok" : "failed"));
    return ! okay;
}

/**
 *
 * @file
 *
 *  PLASMA is a software package provided by:
 *  University of Tennessee, US,
 *  University of Manchester, UK.
 *
 * @generated from compute/pzgetrf.c, normal z -> d, Tue Jul  4 21:23:47 2023
 *
 **/

#include "plasma_async.h"
#include "plasma_context.h"
#include "plasma_descriptor.h"
#include "plasma_internal.h"
#include "plasma_types.h"
#include "plasma_workspace.h"
#include "core_lapack.h"
#include <plasma_core_blas.h>
#include <string.h>
#include <omp.h>
#ifdef LIKWID
#include <likwid-marker.h>
#endif

#define A(m, n)         (double*)plasma_tile_addr(A, m, n)
#define B(m, n)         (double*)plasma_tile_addr(B, m, n)
#define A_PACK(m, n)    (double*)plasma_buffer_addr_general(A, m, n)
#define B_PACK(m, n)    (double*)plasma_buffer_addr_general(B, m, n)
#define L_PACK(m, n)    (double*)plasma_buffer_l_addr_general(A, m, n)

int dgemm_itcopy(long m, long n, double *a, long lda, double *b);
int dgemm_oncopy(long m, long n, double *a, long lda, double *b);
int dgemm_kernel(long, long, long, double, double *, double *, double *, long);

/******************************************************************************/
void plasma_pdgetrf(plasma_desc_t A, int *ipiv,
                    plasma_sequence_t *sequence, plasma_request_t *request)
{
    // Return if failed sequence.
    if (sequence->status != PlasmaSuccess)
        return;

    // Read parameters from the context.
    plasma_context_t *plasma = plasma_context_self();

    // Set tiling parameters.
    int ib = plasma->ib;

    int minmtnt = imin(A.mt, A.nt);

    for (int k = 0; k < minmtnt; k++) {
        double *a00, *a20;
        a00 = A(k, k);
        a20 = A(A.mt-1, k);

        // Create fake dependencies of the whole panel on its individual tiles.
        // These tasks are inserted to generate a correct DAG rather than
        // doing any useful work.
        for (int m = k+1; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:amk[0]) \
                             depend (inout:a00[0]) \
                             priority(1)
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }

        int ma00k = (A.mt-k-1)*A.mb;
        int na00k = plasma_tile_nmain(A, k);
        int lda20 = plasma_tile_mmain(A, A.mt-1);

        int nvak = plasma_tile_nview(A, k);
        int mvak = plasma_tile_mview(A, k);
        int ldak = plasma_tile_mmain(A, k);

        int num_panel_threads = imin(plasma->max_panel_threads,
                                     minmtnt-k);
        // panel
        #pragma omp task depend(inout:a00[0:ma00k*na00k]) \
                         depend(inout:a20[0:lda20*nvak]) \
                         depend(out:ipiv[k*A.mb:mvak]) \
                         priority(1)
        {
            volatile int *max_idx = (int*)malloc(num_panel_threads*sizeof(int));
            if (max_idx == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile double *max_val =
                (double*)malloc(num_panel_threads*sizeof(
                                            double));
            if (max_val == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile int info = 0;

            plasma_barrier_t barrier;
            plasma_barrier_init(&barrier);

            if (sequence->status == PlasmaSuccess) {
                // If nesting would not be expensive on architectures such as
                // KNL, this would resolve the issue with deadlocks caused by
                // tasks expected to run are in fact not launched.
                //#pragma omp parallel for shared(barrier)
                //                         schedule(dynamic,1)
                //                         num_threads(num_panel_threads)
                #pragma omp taskloop untied shared(barrier) \
                                     num_tasks(num_panel_threads) \
                                     priority(2)
                for (int rank = 0; rank < num_panel_threads; rank++) {
                    {
                        plasma_desc_t view =
                            plasma_desc_view(A,
                                             k*A.mb, k*A.nb,
                                             A.m-k*A.mb, nvak);

                        plasma_core_dgetrf(view, &ipiv[k*A.mb], ib,
                                    rank, num_panel_threads,
                                    max_idx, max_val, &info,
                                    &barrier);

                        if (info != 0)
                            plasma_request_fail(sequence, request, k*A.mb+info);
                    }
                }
            }
            #pragma omp taskwait

            free((void*)max_idx);
            free((void*)max_val);

            for (int i = k*A.mb+1; i <= imin(A.m, k*A.mb+nvak); i++)
                ipiv[i-1] += k*A.mb;
        }

        // update
        for (int n = k+1; n < A.nt; n++) {
            double *a01, *a11, *a21;
            a01 = A(k, n);
            a11 = A(k+1, n);
            a21 = A(A.mt-1, n);

            int ma11k = (A.mt-k-2)*A.mb;
            int na11n = plasma_tile_nmain(A, n);
            int lda21 = plasma_tile_mmain(A, A.mt-1);

            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:a00[0:ma00k*na00k]) \
                             depend(in:a20[0:lda20*nvak]) \
                             depend(in:ipiv[k*A.mb:mvak]) \
                             depend(inout:a01[0:ldak*nvan]) \
                             depend(inout:a11[0:ma11k*na11n]) \
                             depend(inout:a21[0:lda21*nvan]) \
                             priority(n == k+1)
            {
                if (sequence->status == PlasmaSuccess) {
                    // geswp
                    int k1 = k*A.mb+1;
                    int k2 = imin(k*A.mb+A.mb, A.m);
                    plasma_desc_t view =
                        plasma_desc_view(A, 0, n*A.nb, A.m, nvan);
                    plasma_core_dgeswp(PlasmaRowwise, view, k1, k2, ipiv, 1);

                    // trsm
                    plasma_core_dtrsm(PlasmaLeft, PlasmaLower,
                               PlasmaNoTrans, PlasmaUnit,
                               mvak, nvan,
                               1.0, A(k, k), ldak,
                                    A(k, n), ldak);
                    // gemm
                    for (int m = k+1; m < A.mt; m++) {
                        int mvam = plasma_tile_mview(A, m);
                        int ldam = plasma_tile_mmain(A, m);

                        #pragma omp task priority(n == k+1)
                        {
                            plasma_core_dgemm(
                                PlasmaNoTrans, PlasmaNoTrans,
                                mvam, nvan, A.nb,
                                -1.0, A(m, k), ldam,
                                      A(k, n), ldak,
                                1.0,  A(m, n), ldam);
                        }
                    }
                }
                #pragma omp taskwait
            }
        }
    }

    // Multidependency of the whole ipiv on the individual chunks
    // corresponding to tiles.
    for (int m = 0; m < minmtnt; m++) {
        // insert dummy task
        #pragma omp task depend (in:ipiv[m*A.mb]) \
                         depend (inout:ipiv[0])
        {
            int l = 1;
            l++;
        }
    }

    // pivoting to the left
    for (int k = 0; k < minmtnt-1; k++) {
        double *a10, *a20;
        a10 = A(k+1, k);
        a20 = A(A.mt-1, k);

        int ma10k = (A.mt-k-2)*A.mb;
        int na00k = plasma_tile_nmain(A, k);
        int lda20 = plasma_tile_mmain(A, A.mt-1);

        int nvak = plasma_tile_nview(A, k);

        #pragma omp task depend(in:ipiv[0:imin(A.m,A.n)]) \
                         depend(inout:a10[0:ma10k*na00k]) \
                         depend(inout:a20[0:lda20*nvak])
        {
            if (sequence->status == PlasmaSuccess) {
                plasma_desc_t view =
                    plasma_desc_view(A, 0, k*A.nb, A.m, A.nb);
                int k1 = (k+1)*A.mb+1;
                int k2 = imin(A.m, A.n);
                plasma_core_dgeswp(PlasmaRowwise, view, k1, k2, ipiv, 1);
            }
        }

        // Multidependency of individual tiles on the whole panel.
        for (int m = k+2; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:a10[0]) \
                             depend (inout:amk[0])
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }
    }
}


/******************************************************************************/
void plasma_pdgetrf_elim_merg(plasma_desc_t A, int *ipiv,
                    plasma_sequence_t *sequence, plasma_request_t *request, double *pA, int lda)
{
	printf("dgetrf_elim_merg\n");

	volatile int *flag_a = NULL;
	flag_a = (int *) malloc (sizeof(int)*A.gmt*A.gnt);
	memset(flag_a, 0, sizeof(int)*A.gmt*A.gnt);

    // Return if failed sequence.
    if (sequence->status != PlasmaSuccess)
        return;

    // Read parameters from the context.
    plasma_context_t *plasma = plasma_context_self();

    // Set tiling parameters.
    int ib = plasma->ib;

    int minmtnt = imin(A.mt, A.nt);

    for (int k = 0; k < minmtnt; k++) {
        double *a00, *a20;
        a00 = A(k, k);
        a20 = A(A.mt-1, k);

        // Create fake dependencies of the whole panel on its individual tiles.
        // These tasks are inserted to generate a correct DAG rather than
        // doing any useful work.
        for (int m = k+1; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:amk[0]) \
                             depend (inout:a00[0]) \
                             priority(1)
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }

        int ma00k = (A.mt-k-1)*A.mb;
        int na00k = plasma_tile_nmain(A, k);

        int lda20 = plasma_tile_mmain(A, A.mt-1);
        int nvak = plasma_tile_nview(A, k);

        int mvak = plasma_tile_mview(A, k);
        int ldak = plasma_tile_mmain(A, k);

        int num_panel_threads = imin(plasma->max_panel_threads,
                                     minmtnt-k);
        // panel
        #pragma omp task depend(inout:a00[0:ma00k*na00k]) \
                         depend(inout:a20[0:lda20*nvak]) \
                         depend(out:ipiv[k*A.mb:mvak]) \
                         priority(1)
        {
            volatile int *max_idx = (int*)malloc(num_panel_threads*sizeof(int));
            if (max_idx == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile double *max_val =
                (double*)malloc(num_panel_threads*sizeof(double));
            if (max_val == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile int info = 0;

            plasma_barrier_t barrier;
            plasma_barrier_init(&barrier);

            if (sequence->status == PlasmaSuccess) {
                // If nesting would not be expensive on architectures such as
                // KNL, this would resolve the issue with deadlocks caused by
                // tasks expected to run are in fact not launched.
                //#pragma omp parallel for shared(barrier)
                //                         schedule(dynamic,1)
                //                         num_threads(num_panel_threads)
                #pragma omp taskloop untied shared(barrier) \
                                     num_tasks(num_panel_threads) \
                                     priority(2)
                for (int rank = 0; rank < num_panel_threads; rank++) {
                    {
                        plasma_desc_t view =
                            plasma_desc_view(A,
                                             k*A.mb, k*A.nb,
                                             A.m-k*A.mb, nvak);

						// plasma_core_dgetrf_elim(&pA[k*A.mb+k*A.nb*lda], lda,
                        //             view, &ipiv[k*A.mb], ib,
                        //             rank, num_panel_threads,
                        //             max_idx, max_val, &info,
                        //             &barrier);

						// LAPACKE_dgetrf(LAPACK_COL_MAJOR, A.m-k*A.mb, nvak, &pA[k*A.mb+k*A.nb*lda], lda, &ipiv[k*A.mb]);
						plasma_core_dgetrf_elim_with_buffer(&pA[k*A.mb+k*A.nb*lda], lda,
                                    view, &ipiv[k*A.mb], ib,
                                    rank, num_panel_threads,
                                    max_idx, max_val, &info,
                                    &barrier);

                        if (info != 0)
                            plasma_request_fail(sequence, request, k*A.mb+info);
                    }
                }
            }
            #pragma omp taskwait

            free((void*)max_idx);
            free((void*)max_val);

            for (int i = k*A.mb+1; i <= imin(A.m, k*A.mb+nvak); i++)
                ipiv[i-1] += k*A.mb;
        }

        // update
        for (int n = k+1; n < A.nt; n++) {
            double *a01, *a11, *a21;
            a01 = A(k, n);
            a11 = A(k+1, n);
            a21 = A(A.mt-1, n);

            int ma11k = (A.mt-k-2)*A.mb;
            int na11n = plasma_tile_nmain(A, n);
            int lda21 = plasma_tile_mmain(A, A.mt-1);

            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:a00[0:ma00k*na00k]) \
                             depend(in:a20[0:lda20*nvak]) \
                             depend(in:ipiv[k*A.mb:mvak]) \
                             depend(inout:a01[0:ldak*nvan]) \
                             depend(inout:a11[0:ma11k*na11n]) \
                             depend(inout:a21[0:lda21*nvan]) \
                             priority(n == k+1)
            {
                if (sequence->status == PlasmaSuccess) {
                    // geswp
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb+1;
                    int k2 = imin(k*A.mb+A.mb, A.m);
					for (int m = k1-1; m <= k2-1; m += 1) {
                        if (ipiv[m]-1 != m) {
                            int m1 = m;
                            int m2 = ipiv[m]-1;

                            cblas_dswap(nvan,
                                        &pA[m1+A.nb*n*lda], lda,
                                        &pA[m2+A.nb*n*lda], lda);
                        }
                    }
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif

                    // trsm
                    plasma_core_dtrsm(PlasmaLeft, PlasmaLower,
                               PlasmaNoTrans, PlasmaUnit,
                               mvak, nvan,
                               1.0, &pA[A.mb*k+A.nb*k*lda], lda,
                                    &pA[A.mb*k+A.nb*n*lda], lda);

                    // gemm
                    for (int m = k+1; m < A.mt; m++) {
                        int mvam = plasma_tile_mview(A, m);
                        int ldam = plasma_tile_mmain(A, m);

                        #pragma omp task priority(n == k+1)
                        {
							// if(__sync_bool_compare_and_swap(&flag_a[k+n*A.gmt], 0, 1)) {
							// 	dgemm_oncopy(A.nb, nvan, &pA[A.mb*k+A.nb*n*lda], lda, A_PACK(k,n));
							// 	flag_a[k+n*A.gmt]++;
							// }

							// if(__sync_bool_compare_and_swap(&flag_a[m+k*A.gmt], 0, 1)) {
							// 	dgemm_itcopy(A.nb, mvam, &pA[A.mb*m+A.nb*k*lda], lda, A_PACK(m,k));
							// 	flag_a[m+k*A.gmt]++;
							// }

							// while(flag_a[m+k*A.gmt] == 1 || flag_a[k+n*A.gmt] == 1);
							// dgemm_kernel(mvam, nvan, A.nb, -1.0, A_PACK(m,k), A_PACK(k,n), &pA[A.mb*m+A.nb*n*lda], lda);

							plasma_core_dgemm(
                                PlasmaNoTrans, PlasmaNoTrans,
                                mvam, nvan, A.nb,
                                -1.0, &pA[A.mb*m+A.nb*k*lda], lda,
                                      &pA[A.mb*k+A.nb*n*lda], lda,
                                1.0,  &pA[A.mb*m+A.nb*n*lda], lda);
                        }
                    }
                }
                #pragma omp taskwait
            }
        }

		for(int m = 0; m <= k; m ++){
            #pragma omp task depend (in:ipiv[m*A.mb]) \
                                depend (inout:ipiv[0])
            {
                int l = 1;
                l ++;
            }
        }

        // swaping to the left, each column before the current panel
        for(int n = 0; n < k; n++){
            double *a00, *a20;

            a00 = A(k, n);
            a20 = A(A.mt-1, n);

            int ma00k = (A.mt-k-1)*A.mb;
            int na00k = plasma_tile_nmain(A, n);  // be careful

            int lda20 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:ipiv[k*A.mb:mvak]) \
                           depend(inout:a00[0:ma00k*na00k]) \
                           depend(inout:a20[0:lda20*nvan])
            {
                if(sequence->status == PlasmaSuccess){

                    int k1 = k*A.mb + 1;
                    int k2 = k*A.mb + mvak;
					#ifdef TRACE
						trace_cpu_start();
					#endif
					for (int m = k1-1; m <= k2-1; m += 1) {
						if (ipiv[m]-1 != m) {
							int m1 = m;
							int m2 = ipiv[m]-1;

							cblas_dswap(nvan,
										&pA[m1+A.nb*n*lda], lda,
										&pA[m2+A.nb*n*lda], lda);
						}
					}
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif
                }
            }
        }
    }
}

/******************************************************************************/
void plasma_pdgesv_elim(plasma_desc_t A, int *ipiv,
                      plasma_desc_t B,
                      plasma_sequence_t *sequence, plasma_request_t *request,
					  double *pA, int lda,
					  double *pB, int ldb)
{
	printf("dgesv_elim\n");

    // Return if failed sequence.
    if (sequence->status != PlasmaSuccess)
        return;

    // Read parameters from the context.
    plasma_context_t *plasma = plasma_context_self();

    // Set tiling parameters.
    int ib = plasma->ib;

    int minmtnt = imin(A.mt, A.nt);

    for (int k = 0; k < minmtnt; k++) {
        double *a00, *a20;
        a00 = A(k, k);
        a20 = A(A.mt-1, k);

        // Create fake dependencies of the whole panel on its individual tiles.
        // These tasks are inserted to generate a correct DAG rather than
        // doing any useful work.
        for (int m = k+1; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:amk[0]) \
                             depend (inout:a00[0]) \
                             priority(1)
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }

        int ma00k = (A.mt-k-1)*A.mb;
        int na00k = plasma_tile_nmain(A, k);

        int lda20 = plasma_tile_mmain(A, A.mt-1);
        int nvak = plasma_tile_nview(A, k);

        int mvak = plasma_tile_mview(A, k);
        int ldak = plasma_tile_mmain(A, k);

        int num_panel_threads = imin(plasma->max_panel_threads,
                                     minmtnt-k);
        // panel
        #pragma omp task depend(inout:a00[0:ma00k*na00k]) \
                         depend(inout:a20[0:lda20*nvak]) \
                         depend(out:ipiv[k*A.mb:mvak]) \
                         priority(1)
        {
            volatile int *max_idx = (int*)malloc(num_panel_threads*sizeof(int));
            if (max_idx == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile double *max_val =
                (double*)malloc(num_panel_threads*sizeof(double));
            if (max_val == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile int info = 0;

            plasma_barrier_t barrier;
            plasma_barrier_init(&barrier);

            if (sequence->status == PlasmaSuccess) {
                // If nesting would not be expensive on architectures such as
                // KNL, this would resolve the issue with deadlocks caused by
                // tasks expected to run are in fact not launched.
                //#pragma omp parallel for shared(barrier)
                //                         schedule(dynamic,1)
                //                         num_threads(num_panel_threads)
                #pragma omp taskloop untied shared(barrier) \
                                     num_tasks(num_panel_threads) \
                                     priority(2)
                for (int rank = 0; rank < num_panel_threads; rank++) {
                    {
                        plasma_desc_t view =
                            plasma_desc_view(A,
                                             k*A.mb, k*A.nb,
                                             A.m-k*A.mb, nvak);

						// plasma_core_dgetrf_elim(&pA[k*A.mb+k*A.nb*lda], lda,
                        //             view, &ipiv[k*A.mb], ib,
                        //             rank, num_panel_threads,
                        //             max_idx, max_val, &info,
                        //             &barrier);
						plasma_core_dgetrf_elim_with_buffer(&pA[k*A.mb+k*A.nb*lda], lda,
                                    view, &ipiv[k*A.mb], ib,
                                    rank, num_panel_threads,
                                    max_idx, max_val, &info,
                                    &barrier);

                        if (info != 0)
                            plasma_request_fail(sequence, request, k*A.mb+info);
                    }
                }
            }
            #pragma omp taskwait

            free((void*)max_idx);
            free((void*)max_val);

            for (int i = k*A.mb+1; i <= imin(A.m, k*A.mb+nvak); i++)
                ipiv[i-1] += k*A.mb;
        }

        // update
        for (int n = k+1; n < A.nt; n++) {
            double *a01, *a11, *a21;
            a01 = A(k, n);
            a11 = A(k+1, n);
            a21 = A(A.mt-1, n);

            int ma11k = (A.mt-k-2)*A.mb;
            int na11n = plasma_tile_nmain(A, n);
            int lda21 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:a00[0:ma00k*na00k]) \
                             depend(in:a20[0:lda20*nvak]) \
                             depend(in:ipiv[k*A.mb:mvak]) \
                             depend(inout:a01[0:ldak*nvan]) \
                             depend(inout:a11[0:ma11k*na11n]) \
                             depend(inout:a21[0:lda21*nvan]) \
                             priority(n == k+1)
            {
                if (sequence->status == PlasmaSuccess) {
                    // geswp
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb+1;
                    int k2 = imin(k*A.mb+A.mb, A.m);
					for (int m = k1-1; m <= k2-1; m += 1) {
                        if (ipiv[m]-1 != m) {
                            int m1 = m;
                            int m2 = ipiv[m]-1;

                            cblas_dswap(nvan,
                                        &pA[m1+A.nb*n*lda], lda,
                                        &pA[m2+A.nb*n*lda], lda);
                        }
                    }
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif

                    // trsm
                    plasma_core_dtrsm(PlasmaLeft, PlasmaLower,
                               PlasmaNoTrans, PlasmaUnit,
                               mvak, nvan,
                               1.0, &pA[A.mb*k+A.nb*k*lda], lda,
                                    &pA[A.mb*k+A.nb*n*lda], lda);

                    // gemm
                    for (int m = k+1; m < A.mt; m++) {
                        int mvam = plasma_tile_mview(A, m);
                        int ldam = plasma_tile_mmain(A, m);

                        #pragma omp task priority(n == k+1)
                        {
							plasma_core_dgemm(
                                PlasmaNoTrans, PlasmaNoTrans,
                                mvam, nvan, A.nb,
                                -1.0, &pA[A.mb*m+A.nb*k*lda], lda,
                                      &pA[A.mb*k+A.nb*n*lda], lda,
                                1.0,  &pA[A.mb*m+A.nb*n*lda], lda);
                        }
                    }
                }
                #pragma omp taskwait
            }
        }
    }

	// Multidependency of the whole ipiv on the individual chunks
    // corresponding to tiles.
    for (int m = 0; m < minmtnt; m++) {
        // insert dummy task
        #pragma omp task depend (in:ipiv[m*A.mb]) \
                         depend (inout:ipiv[0])
        {
            int l = 1;
            l++;
        }
    }

    // pivoting to the left
    for (int k = 0; k < minmtnt-1; k++) {
        double *a10, *a20;
        a10 = A(k+1, k);
        a20 = A(A.mt-1, k);

        int ma10k = (A.mt-k-2)*A.mb;
        int na00k = plasma_tile_nmain(A, k);
        int lda20 = plasma_tile_mmain(A, A.mt-1);
        int nvak = plasma_tile_nview(A, k);

        #pragma omp task depend(in:ipiv[0:imin(A.m,A.n)]) \
                         depend(inout:a10[0:ma10k*na00k]) \
                         depend(inout:a20[0:lda20*nvak])
        {
            if(sequence->status == PlasmaSuccess){
				#ifdef TRACE
					trace_cpu_start();
				#endif
				int k1 = (k+1)*A.mb+1;
				int k2 = imin(A.m,A.n);
				for (int m = k1-1; m <= k2-1; m += 1) {
					if (ipiv[m]-1 != m) {
						int m1 = m;
						int m2 = ipiv[m]-1;

						cblas_dswap(na00k,
									&pA[m1+A.nb*k*lda], lda,
									&pA[m2+A.nb*k*lda], lda);
					}
				}
				#ifdef TRACE
					trace_cpu_stop("DarkSeaGreen");
					trace_label("DarkSeaGreen", "SWAP");
				#endif
			}
        }

        // Multidependency of individual tiles on the whole panel.
        for (int m = k+2; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:a10[0]) \
                             depend (inout:amk[0])
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }
    }

	// swaping to matrix B -> gemm -> trsm
	for(int n = 0; n < B.nt; n ++) {
		double *b00, *b20;
		
		b00 = B(0, n);
		b20 = B(B.mt-1, n);
		int mb00 = (B.mt-1)*B.mb;
		int nb00 = plasma_tile_nmain(B,n);
		int ldb20 = plasma_tile_mmain(B, B.mt-1);
		int nvb20 = plasma_tile_nview(B, n);

		// swaping to matrix B
		#pragma omp task depend (in:ipiv[0:B.m]) \
						depend (inout:b00[0:mb00*nb00]) \
						depend (inout:b20[0:ldb20*nvb20])
		{
			#ifdef TRACE
				trace_cpu_start();
			#endif
			int k1 = 1;
			int k2 = B.m;
			int nvbn = plasma_tile_nview(B, n);
			for (int m = k1-1; m <= k2-1; m += 1) {
				if (ipiv[m]-1 != m) {
					int m1 = m;
					int m2 = ipiv[m]-1;

					cblas_dswap(nvbn,
								&pB[m1+B.nb*n*ldb], ldb,
								&pB[m2+B.nb*n*ldb], ldb);
				}
			}
			#ifdef TRACE
				trace_cpu_stop("DarkSeaGreen");
				trace_label("DarkSeaGreen", "SWAP");
			#endif
		}

		// trsm -> gemm
		for(int k = 0; k < B.mt; k ++) {
			int mvbk = plasma_tile_mview(B, k);
			int nvbn = plasma_tile_nview(B, n);

			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbk*mvbk]) \
							depend(inout:bkn[0:mvbk*nvbn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaLower, PlasmaNoTrans, PlasmaUnit,
							mvbk, nvbn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);

			for(int m = k+1; m < B.mt; m ++){
				double *amk = A(m, k), *bkn =B(k, n), *bmn = B(m, n);
				int mvak = plasma_tile_mview(A, m); 

				#pragma omp task depend(in:amk[0:mvak*B.mb]) \
								depend(in:bkn[0:B.mb*nvbn]) \
								depend(inout:bmn[0:mvak*nvbn])
				plasma_core_dgemm(
					PlasmaNoTrans, PlasmaNoTrans,
					mvak, nvbn, B.mb,
					-1.0, &pA[m*A.mb+k*A.nb*lda], lda,
						  &pB[k*B.mb+n*B.nb*ldb], ldb,
					1.0,  &pB[m*B.mb+n*B.nb*ldb], ldb);
			}
		}
	}

	// colunm first
	for(int n = 0; n < B.nt; n ++){
		for(int k = B.mt-1; k >= 0; k --){
			int mvbkn = plasma_tile_mview(B, k);
			int nvbkn = plasma_tile_nview(B, n);

			// trsm
			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbkn*mvbkn]) \
							depend(inout:bkn[0:mvbkn*nvbkn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaUpper, PlasmaNoTrans, PlasmaNonUnit,
							mvbkn, nvbkn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);

			// gemm
			int nvak = plasma_tile_nview(A, k);
			for(int m = k-1; m >= 0; m --) {
				double *amk = A(m, k), *bkn = B(k, n), *bmn = B(m, n);

				#pragma omp task depend(in:amk[0:A.mb*nvak]) \
								depend(in:bkn[0:mvbkn*nvbkn]) \
								depend(inout:bmn[0:B.mb*nvbkn])
				{
					plasma_core_dgemm(
						PlasmaNoTrans, PlasmaNoTrans,
						B.mb, nvbkn, mvbkn,
						-1.0, &pA[m*A.mb+k*A.nb*lda], lda,
							  &pB[k*B.mb+n*B.nb*ldb], ldb,
						1.0,  &pB[m*B.mb+n*B.nb*ldb], ldb);
				}
			}
		}
	}
}

/******************************************************************************/
void plasma_pdgesv_elim_merg(plasma_desc_t A, int *ipiv,
                      plasma_desc_t B,
                      plasma_sequence_t *sequence, plasma_request_t *request,
					  double *pA, int lda,
					  double *pB, int ldb)
{
	printf("dgesv_elim_merg\n");

    // Return if failed sequence.
    if (sequence->status != PlasmaSuccess)
        return;

    // Read parameters from the context.
    plasma_context_t *plasma = plasma_context_self();

    // Set tiling parameters.
    int ib = plasma->ib;

    int minmtnt = imin(A.mt, A.nt);

    for (int k = 0; k < minmtnt; k++) {
        double *a00, *a20;
        a00 = A(k, k);
        a20 = A(A.mt-1, k);

        // Create fake dependencies of the whole panel on its individual tiles.
        // These tasks are inserted to generate a correct DAG rather than
        // doing any useful work.
        for (int m = k+1; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:amk[0]) \
                             depend (inout:a00[0]) \
                             priority(1)
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }

        int ma00k = (A.mt-k-1)*A.mb;
        int na00k = plasma_tile_nmain(A, k);

        int lda20 = plasma_tile_mmain(A, A.mt-1);
        int nvak = plasma_tile_nview(A, k);

        int mvak = plasma_tile_mview(A, k);
        int ldak = plasma_tile_mmain(A, k);

        int num_panel_threads = imin(plasma->max_panel_threads,
                                     minmtnt-k);
        // panel
        #pragma omp task depend(inout:a00[0:ma00k*na00k]) \
                         depend(inout:a20[0:lda20*nvak]) \
                         depend(out:ipiv[k*A.mb:mvak]) \
                         priority(1)
        {
            volatile int *max_idx = (int*)malloc(num_panel_threads*sizeof(int));
            if (max_idx == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile double *max_val =
                (double*)malloc(num_panel_threads*sizeof(double));
            if (max_val == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile int info = 0;

            plasma_barrier_t barrier;
            plasma_barrier_init(&barrier);

            if (sequence->status == PlasmaSuccess) {
                // If nesting would not be expensive on architectures such as
                // KNL, this would resolve the issue with deadlocks caused by
                // tasks expected to run are in fact not launched.
                //#pragma omp parallel for shared(barrier)
                //                         schedule(dynamic,1)
                //                         num_threads(num_panel_threads)
                #pragma omp taskloop untied shared(barrier) \
                                     num_tasks(num_panel_threads) \
                                     priority(2)
                for (int rank = 0; rank < num_panel_threads; rank++) {
                    {
                        plasma_desc_t view =
                            plasma_desc_view(A,
                                             k*A.mb, k*A.nb,
                                             A.m-k*A.mb, nvak);

						// plasma_core_dgetrf_elim(&pA[k*A.mb+k*A.nb*lda], lda,
                        //             view, &ipiv[k*A.mb], ib,
                        //             rank, num_panel_threads,
                        //             max_idx, max_val, &info,
                        //             &barrier);
						plasma_core_dgetrf_elim_with_buffer(&pA[k*A.mb+k*A.nb*lda], lda,
                                    view, &ipiv[k*A.mb], ib,
                                    rank, num_panel_threads,
                                    max_idx, max_val, &info,
                                    &barrier);

                        if (info != 0)
                            plasma_request_fail(sequence, request, k*A.mb+info);
                    }
                }
            }
            #pragma omp taskwait

            free((void*)max_idx);
            free((void*)max_val);

            for (int i = k*A.mb+1; i <= imin(A.m, k*A.mb+nvak); i++)
                ipiv[i-1] += k*A.mb;
        }

        // update
        for (int n = k+1; n < A.nt; n++) {
            double *a01, *a11, *a21;
            a01 = A(k, n);
            a11 = A(k+1, n);
            a21 = A(A.mt-1, n);

            int ma11k = (A.mt-k-2)*A.mb;
            int na11n = plasma_tile_nmain(A, n);
            int lda21 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:a00[0:ma00k*na00k]) \
                             depend(in:a20[0:lda20*nvak]) \
                             depend(in:ipiv[k*A.mb:mvak]) \
                             depend(inout:a01[0:ldak*nvan]) \
                             depend(inout:a11[0:ma11k*na11n]) \
                             depend(inout:a21[0:lda21*nvan]) \
                             priority(n == k+1)
            {
                if (sequence->status == PlasmaSuccess) {
                    // geswp
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb+1;
                    int k2 = imin(k*A.mb+A.mb, A.m);
					for (int m = k1-1; m <= k2-1; m += 1) {
                        if (ipiv[m]-1 != m) {
                            int m1 = m;
                            int m2 = ipiv[m]-1;

                            cblas_dswap(nvan,
                                        &pA[m1+A.nb*n*lda], lda,
                                        &pA[m2+A.nb*n*lda], lda);
                        }
                    }
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif

                    // trsm
                    plasma_core_dtrsm(PlasmaLeft, PlasmaLower,
                               PlasmaNoTrans, PlasmaUnit,
                               mvak, nvan,
                               1.0, &pA[A.mb*k+A.nb*k*lda], lda,
                                    &pA[A.mb*k+A.nb*n*lda], lda);

                    // gemm
                    for (int m = k+1; m < A.mt; m++) {
                        int mvam = plasma_tile_mview(A, m);
                        int ldam = plasma_tile_mmain(A, m);

                        #pragma omp task priority(n == k+1)
                        {
							plasma_core_dgemm(
                                PlasmaNoTrans, PlasmaNoTrans,
                                mvam, nvan, A.nb,
                                -1.0, &pA[A.mb*m+A.nb*k*lda], lda,
                                      &pA[A.mb*k+A.nb*n*lda], lda,
                                1.0,  &pA[A.mb*m+A.nb*n*lda], lda);
                        }
                    }
                }
                #pragma omp taskwait
            }
        }

		for(int m = 0; m <= k; m ++) {
            #pragma omp task depend (in:ipiv[m*A.mb]) \
                                depend (inout:ipiv[0])
            {
                int l = 1;
                l ++;
            }
        }

        // swaping to the left, each column before the current panel
        for(int n = 0; n < k; n++) {
            double *a00, *a20;

            a00 = A(k, n);
            a20 = A(A.mt-1, n);

            int ma00k = (A.mt-k-1)*A.mb;
            int na00k = plasma_tile_nmain(A, n);  // be careful

            int lda20 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:ipiv[k*A.mb:mvak]) \
                           depend(inout:a00[0:ma00k*na00k]) \
                           depend(inout:a20[0:lda20*nvan])
            {
                if(sequence->status == PlasmaSuccess){
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb + 1;
                    int k2 = k*A.mb + mvak;
					for (int m = k1-1; m <= k2-1; m += 1) {
						if (ipiv[m]-1 != m) {
							int m1 = m;
							int m2 = ipiv[m]-1;

							cblas_dswap(nvan,
										&pA[m1+A.nb*n*lda], lda,
										&pA[m2+A.nb*n*lda], lda);
						}
					}
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif
                }
            }
        }

		// swaping to matrix B -> gemm -> trsm
		for(int n = 0; n < B.nt; n ++) {
			double *b00, *b20;
			
			b00 = B(0, n);
			b20 = B(B.mt-1, n);
			int mb00 = (B.mt-1)*B.mb;
			int nb00 = plasma_tile_nmain(B,n);
			int ldb20 = plasma_tile_mmain(B, B.mt-1);
			int nvb20 = plasma_tile_nview(B, n);

			// swaping to matrix B
			#pragma omp task depend (in:ipiv[k*A.mb:mvak]) \
							depend (inout:b00[0:mb00*nb00]) \
							depend (inout:b20[0:ldb20*nvb20])
			{
				#ifdef TRACE
					trace_cpu_start();
				#endif
				int k1 = k*A.mb + 1;
				int k2 = k*A.mb + mvak;
				int nvbn = plasma_tile_nview(B, n);
				for (int m = k1-1; m <= k2-1; m += 1) {
					if (ipiv[m]-1 != m) {
						int m1 = m;
						int m2 = ipiv[m]-1;

						cblas_dswap(nvbn,
									&pB[m1+B.nb*n*ldb], ldb,
									&pB[m2+B.nb*n*ldb], ldb);
					}
				}
				#ifdef TRACE
					trace_cpu_stop("DarkSeaGreen");
					trace_label("DarkSeaGreen", "SWAP");
				#endif
			}

			// gemm -> trsm of B
			int mvbk = plasma_tile_mview(B, k);
            int nvbn = plasma_tile_nview(B, n);

            for(int m = 0; m < k; m ++){
				double *akm = A(k, m), *bmn = B(m, n), *bkn =B(k, n);

				#pragma omp task depend(in:akm[0:mvbk*A.nb]) \
								depend(in:bmn[0:B.nb*nvbn]) \
								depend(inout:bkn[0:mvbk*nvbn])
				plasma_core_dgemm(
					PlasmaNoTrans, PlasmaNoTrans,
					mvbk, nvbn, B.mb,
					-1.0, &pA[k*A.mb+m*A.nb*lda], lda,
						  &pB[m*B.mb+n*B.nb*ldb], ldb,
					1.0,  &pB[k*B.mb+n*B.nb*ldb], ldb);
			}

			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbk*mvbk]) \
							depend(inout:bkn[0:mvbk*nvbn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaLower, PlasmaNoTrans, PlasmaUnit,
							mvbk, nvbn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);
		}
    }

	// colunm first
	for(int n = 0; n < B.nt; n ++){
		for(int k = B.mt-1; k >= 0; k --){
			int mvbkn = plasma_tile_mview(B, k);
			int nvbkn = plasma_tile_nview(B, n);

			// trsm
			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbkn*mvbkn]) \
							depend(inout:bkn[0:mvbkn*nvbkn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaUpper, PlasmaNoTrans, PlasmaNonUnit,
							mvbkn, nvbkn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);

			// gemm
			int nvak = plasma_tile_nview(A, k);
			for(int m = k-1; m >= 0; m --) {
				double *amk = A(m, k), *bkn = B(k, n), *bmn = B(m, n);

				#pragma omp task depend(in:amk[0:A.mb*nvak]) \
								depend(in:bkn[0:mvbkn*nvbkn]) \
								depend(inout:bmn[0:B.mb*nvbkn])
				{
					plasma_core_dgemm(
						PlasmaNoTrans, PlasmaNoTrans,
						B.mb, nvbkn, mvbkn,
						-1.0, &pA[m*A.mb+k*A.nb*lda], lda,
							  &pB[k*B.mb+n*B.nb*ldb], ldb,
						1.0,  &pB[m*B.mb+n*B.nb*ldb], ldb);
				}
			}
		}
	}
}


void plasma_pdgesv_elim_merg_pack(plasma_desc_t A, int *ipiv,
                      plasma_desc_t B,
                      plasma_sequence_t *sequence, plasma_request_t *request,
					  double *pA, int lda,
					  double *pB, int ldb)
{
	printf("dgesv_elim_merg_pack\n");

	volatile int *flag_a_trf, *flag_a_trsm, *flag_b_l, *flag_b_u;
	flag_a_trf  = (int *) malloc (sizeof(int)*A.gmt*A.gnt);
	flag_a_trsm = (int *) malloc (sizeof(int)*A.gmt*A.gnt);
	memset(flag_a_trf , 0, sizeof(int)*A.gmt*A.gnt);
	memset(flag_a_trsm, 0, sizeof(int)*A.gmt*A.gnt);
	flag_b_l = (int *) malloc (sizeof(int)*B.gmt*B.gnt);
	flag_b_u = (int *) malloc (sizeof(int)*B.gmt*B.gnt);
	memset(flag_b_l, 0, sizeof(int)*B.gmt*B.gnt);
	memset(flag_b_u, 0, sizeof(int)*B.gmt*B.gnt);

    // Return if failed sequence.
    if (sequence->status != PlasmaSuccess)
        return;

    // Read parameters from the context.
    plasma_context_t *plasma = plasma_context_self();

    // Set tiling parameters.
    int ib = plasma->ib;

    int minmtnt = imin(A.mt, A.nt);

    for (int k = 0; k < minmtnt; k++) {
        double *a00, *a20;
        a00 = A(k, k);
        a20 = A(A.mt-1, k);

        // Create fake dependencies of the whole panel on its individual tiles.
        // These tasks are inserted to generate a correct DAG rather than
        // doing any useful work.
        for (int m = k+1; m < A.mt-1; m++) {
            double *amk = A(m, k);
            #pragma omp task depend (in:amk[0]) \
                             depend (inout:a00[0]) \
                             priority(1)
            {
                // Do some funny work here. It appears so that the compiler
                // might not insert the task if it is completely empty.
                int l = 1;
                l++;
            }
        }

        int ma00k = (A.mt-k-1)*A.mb;
        int na00k = plasma_tile_nmain(A, k);

        int lda20 = plasma_tile_mmain(A, A.mt-1);
        int nvak = plasma_tile_nview(A, k);

        int mvak = plasma_tile_mview(A, k);
        int ldak = plasma_tile_mmain(A, k);

        int num_panel_threads = imin(plasma->max_panel_threads,
                                     minmtnt-k);
        // panel
        #pragma omp task depend(inout:a00[0:ma00k*na00k]) \
                         depend(inout:a20[0:lda20*nvak]) \
                         depend(out:ipiv[k*A.mb:mvak]) \
                         priority(1)
        {
            volatile int *max_idx = (int*)malloc(num_panel_threads*sizeof(int));
            if (max_idx == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile double *max_val =
                (double*)malloc(num_panel_threads*sizeof(double));
            if (max_val == NULL)
                plasma_request_fail(sequence, request, PlasmaErrorOutOfMemory);

            volatile int info = 0;

            plasma_barrier_t barrier;
            plasma_barrier_init(&barrier);

            if (sequence->status == PlasmaSuccess) {
                // If nesting would not be expensive on architectures such as
                // KNL, this would resolve the issue with deadlocks caused by
                // tasks expected to run are in fact not launched.
                //#pragma omp parallel for shared(barrier)
                //                         schedule(dynamic,1)
                //                         num_threads(num_panel_threads)
                #pragma omp taskloop untied shared(barrier) \
                                     num_tasks(num_panel_threads) \
                                     priority(2)
                for (int rank = 0; rank < num_panel_threads; rank++) {
                    {
                        plasma_desc_t view =
                            plasma_desc_view(A,
                                             k*A.mb, k*A.nb,
                                             A.m-k*A.mb, nvak);

						// plasma_core_dgetrf_elim(&pA[k*A.mb+k*A.nb*lda], lda,
                        //             view, &ipiv[k*A.mb], ib,
                        //             rank, num_panel_threads,
                        //             max_idx, max_val, &info,
                        //             &barrier);
						plasma_core_dgetrf_elim_with_buffer(&pA[k*A.mb+k*A.nb*lda], lda,
                                    view, &ipiv[k*A.mb], ib,
                                    rank, num_panel_threads,
                                    max_idx, max_val, &info,
                                    &barrier);

                        if (info != 0)
                            plasma_request_fail(sequence, request, k*A.mb+info);
                    }
                }
            }
            #pragma omp taskwait

            free((void*)max_idx);
            free((void*)max_val);

            for (int i = k*A.mb+1; i <= imin(A.m, k*A.mb+nvak); i++)
                ipiv[i-1] += k*A.mb;
        }

        // update
        for (int n = k+1; n < A.nt; n++) {
            double *a01, *a11, *a21;
            a01 = A(k, n);
            a11 = A(k+1, n);
            a21 = A(A.mt-1, n);

            int ma11k = (A.mt-k-2)*A.mb;
            int na11n = plasma_tile_nmain(A, n);
            int lda21 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:a00[0:ma00k*na00k]) \
                             depend(in:a20[0:lda20*nvak]) \
                             depend(in:ipiv[k*A.mb:mvak]) \
                             depend(inout:a01[0:ldak*nvan]) \
                             depend(inout:a11[0:ma11k*na11n]) \
                             depend(inout:a21[0:lda21*nvan]) \
                             priority(n == k+1)
            {
                if (sequence->status == PlasmaSuccess) {
                    // geswp
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb+1;
                    int k2 = imin(k*A.mb+A.mb, A.m);
					for (int m = k1-1; m <= k2-1; m += 1) {
                        if (ipiv[m]-1 != m) {
                            int m1 = m;
                            int m2 = ipiv[m]-1;
                            cblas_dswap(nvan,
                                        &pA[m1+A.nb*n*lda], lda,
                                        &pA[m2+A.nb*n*lda], lda);
                        }
                    }
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif

                    // trsm
                    plasma_core_dtrsm(PlasmaLeft, PlasmaLower,
                               PlasmaNoTrans, PlasmaUnit,
                               mvak, nvan,
                               1.0, &pA[A.mb*k+A.nb*k*lda], lda,
                                    &pA[A.mb*k+A.nb*n*lda], lda);

                    // gemm
                    for (int m = k+1; m < A.mt; m++) {
                        int mvam = plasma_tile_mview(A, m);
                        int ldam = plasma_tile_mmain(A, m);

						// if(n == k+1) {
						// 	#pragma omp task priority(n  == k+1)
						// 	plasma_core_dgemm(
						// 	    PlasmaNoTrans, PlasmaNoTrans,
						// 	    mvam, nvan, A.nb,
						// 	    -1.0, &pA[A.mb*m+A.nb*k*lda], lda,
						// 	          &pA[A.mb*k+A.nb*n*lda], lda,
						// 	    1.0,  &pA[A.mb*m+A.nb*n*lda], lda);
						// } else {
							#pragma omp task priority(n == k+1)
							{
							#ifdef LIKWID
								LIKWID_MARKER_START("demo");
							#endif
							#ifdef PAPI
								int EventSet = -1;
								trace_cache_start(&EventSet);
							#endif
							// #ifdef TRACE
							// 	trace_cpu_start();
							// #endif
							#ifdef TIME
								double time_cost,start,ops=2.0*mvam*nvan*A.nb,gflops;
								start = omp_get_wtime();
							#endif

								#ifdef TRACE
									trace_cpu_start();
								#endif
								if(__sync_bool_compare_and_swap(&flag_a_trf[k+n*A.gmt], 0, 1)) {
									dgemm_oncopy(A.nb, nvan, &pA[A.mb*k+A.nb*n*lda], lda, A_PACK(k,n));
									flag_a_trf[k+n*A.gmt]++;
								}
								if(__sync_bool_compare_and_swap(&flag_a_trf[m+k*A.gmt], 0, 1)) {
									dgemm_itcopy(A.nb, mvam, &pA[A.mb*m+A.nb*k*lda], lda, A_PACK(m,k));
									flag_a_trf[m+k*A.gmt]++;
								}
								#ifdef TRACE
									trace_cpu_stop("Khaki");
									trace_label("Khaki", "PACK");
								#endif

								#ifdef TRACE
									trace_cpu_start();
								#endif
								while(flag_a_trf[m+k*A.gmt] == 1 || flag_a_trf[k+n*A.gmt] == 1);
								#ifdef TRACE
									trace_cpu_stop("Pink");
									trace_label("Pink", "WAIT");
								#endif
								
								#ifdef TRACE
									trace_cpu_start();
								#endif
								dgemm_kernel(mvam, nvan, A.nb, -1.0, A_PACK(m,k), A_PACK(k,n), &pA[A.mb*m+A.nb*n*lda], lda);
								#ifdef TRACE
									trace_cpu_stop("Green");
									trace_label("Green", "MKERNEL");
								#endif

							#ifdef TIME
								time_cost = omp_get_wtime() - start;
								gflops = ops/time_cost/1.0e9;
								printf("m=%d,n=%d,k=%d,time_cost=%.2lf,ops=%.2lf,gflops,%.2lf\n",mvam,nvan,A.nb,time_cost,ops,gflops);
							#endif
							// #ifdef TRACE
							// 	trace_cpu_stop("LightSeaGreen");
							// 	trace_label("LightSeaGreen", "KERNEL");
							// #endif
							#ifdef PAPI
								trace_cache_stop(&EventSet, "KERNEL");
							#endif
							#ifdef LIKWID
								LIKWID_MARKER_STOP("demo");
							#endif
								// plasma_core_dgemm(
								//     PlasmaNoTrans, PlasmaNoTrans,
								//     mvam, nvan, A.nb,
								//     -1.0, &pA[A.mb*m+A.nb*k*lda], lda,
								//           &pA[A.mb*k+A.nb*n*lda], lda,
								//     1.0,  &pA[A.mb*m+A.nb*n*lda], lda);
							}
						// }
					}
                }
                #pragma omp taskwait
            }
        }

		for(int m = 0; m <= k; m ++) {
            #pragma omp task depend (in:ipiv[m*A.mb]) \
                                depend (inout:ipiv[0])
            {
                int l = 1;
                l ++;
            }
        }

        // swaping to the left, each column before the current panel
        for(int n = 0; n < k; n++) {
            double *a00, *a20;

            a00 = A(k, n);
            a20 = A(A.mt-1, n);

            int ma00k = (A.mt-k-1)*A.mb;
            int na00k = plasma_tile_nmain(A, n);  // be careful

            int lda20 = plasma_tile_mmain(A, A.mt-1);
            int nvan = plasma_tile_nview(A, n);

            #pragma omp task depend(in:ipiv[k*A.mb:mvak]) \
                           depend(inout:a00[0:ma00k*na00k]) \
                           depend(inout:a20[0:lda20*nvan])
            {
                if(sequence->status == PlasmaSuccess){
					#ifdef TRACE
						trace_cpu_start();
					#endif
                    int k1 = k*A.mb + 1;
                    int k2 = k*A.mb + mvak;
					for (int m = k1-1; m <= k2-1; m += 1) {
						if (ipiv[m]-1 != m) {
							int m1 = m;
							int m2 = ipiv[m]-1;

							cblas_dswap(nvan,
										&pA[m1+A.nb*n*lda], lda,
										&pA[m2+A.nb*n*lda], lda);
						}
					}
					#ifdef TRACE
						trace_cpu_stop("DarkSeaGreen");
						trace_label("DarkSeaGreen", "SWAP");
					#endif
                }
            }
        }

		// swaping to matrix B -> gemm -> trsm -> pack B
		for(int n = 0; n < B.nt; n ++) {
			double *b00, *b20;
			
			b00 = B(0, n);
			b20 = B(B.mt-1, n);
			int mb00 = (B.mt-1)*B.mb;
			int nb00 = plasma_tile_nmain(B,n);
			int ldb20 = plasma_tile_mmain(B, B.mt-1);
			int nvb20 = plasma_tile_nview(B, n);

			// swaping to matrix B
			#pragma omp task depend (in:ipiv[k*A.mb:mvak]) \
							depend (inout:b00[0:mb00*nb00]) \
							depend (inout:b20[0:ldb20*nvb20])
			{
				#ifdef TRACE
					trace_cpu_start();
				#endif
				int k1 = k*A.mb + 1;
				int k2 = k*A.mb + mvak;
				int nvbn = plasma_tile_nview(B, n);
				for (int m = k1-1; m <= k2-1; m += 1) {
					if (ipiv[m]-1 != m) {
						int m1 = m;
						int m2 = ipiv[m]-1;

						cblas_dswap(nvbn,
									&pB[m1+B.nb*n*ldb], ldb,
									&pB[m2+B.nb*n*ldb], ldb);
					}
				}
				#ifdef TRACE
					trace_cpu_stop("DarkSeaGreen");
					trace_label("DarkSeaGreen", "SWAP");
				#endif
			}

			// gemm -> trsm of B
			int mvbk = plasma_tile_mview(B, k);
            int nvbn = plasma_tile_nview(B, n);

            for(int m = 0; m < k; m ++) {
				double *akm = A(k, m), *bmn = B(m, n), *bkn =B(k, n);

				#pragma omp task depend(in:akm[0:mvbk*A.nb]) \
								depend(in:bmn[0:B.nb*nvbn]) \
								depend(inout:bkn[0:mvbk*nvbn])
				{
				#ifdef LIKWID
					LIKWID_MARKER_START("demo");
				#endif
				#ifdef PAPI
					int EventSet = -1;
					trace_cache_start(&EventSet);
				#endif
				// #ifdef TRACE
				// 	trace_cpu_start();
				// #endif
				#ifdef TIME
					double time_cost,start,ops=2.0*mvbk*nvbn*B.mb,gflops;
					start = omp_get_wtime();
				#endif

					#ifdef TRACE
						trace_cpu_start();
					#endif
					if(__sync_bool_compare_and_swap(&flag_b_l[m+n*B.gmt], 0, 1)) {
						dgemm_oncopy(B.mb, nvbn, &pB[m*B.mb+n*B.nb*ldb], ldb, B_PACK(m, n));
						flag_b_l[m+n*B.gmt]++;
					}
					if(__sync_bool_compare_and_swap(&flag_a_trsm[k+m*A.gmt], 0, 1)) {
						dgemm_itcopy(B.mb, mvbk, &pA[k*A.mb+m*A.nb*lda], lda, L_PACK(k, m));
						flag_a_trsm[k+m*A.gmt]++;
					}
					#ifdef TRACE
						trace_cpu_stop("Khaki");
						trace_label("Khaki", "PACK");
					#endif

					#ifdef TRACE
						trace_cpu_start();
					#endif
					while(flag_a_trsm[k+m*A.gmt] == 1 ||flag_b_l[m+n*B.gmt] == 1);
					#ifdef TRACE
						trace_cpu_stop("Pink");
						trace_label("Pink", "WAIT");
					#endif

					#ifdef TRACE
						trace_cpu_start();
					#endif
					dgemm_kernel(mvbk, nvbn, B.mb, -1.0, L_PACK(k, m), B_PACK(m, n), &pB[k*B.mb+n*B.nb*ldb], ldb);
					#ifdef TRACE
						trace_cpu_stop("Green");
						trace_label("Green", "MKERNEL");
					#endif

				#ifdef TIME
					time_cost = omp_get_wtime() - start;
					gflops = ops/time_cost/1.0e9;
					printf("m=%d,n=%d,k=%d,time_cost=%.2lf,ops=%.2lf,gflops,%.2lf\n",mvbk,nvbn,B.mb,time_cost,ops,gflops);
				#endif
				// #ifdef TRACE
				// 	trace_cpu_stop("LightSeaGreen");
				// 	trace_label("LightSeaGreen", "KERNEL");
				// #endif
				#ifdef PAPI
					trace_cache_stop(&EventSet, "KERNEL");
				#endif
				#ifdef LIKWID
					LIKWID_MARKER_STOP("demo");
				#endif
					// plasma_core_dgemm(
					// 	PlasmaNoTrans, PlasmaNoTrans,
					// 	mvbk, nvbn, B.mb,
					// 	-1.0, &pA[k*A.mb+m*A.nb*lda], lda,
					// 		  &pB[m*B.mb+n*B.nb*ldb], ldb,
					// 	1.0,  &pB[k*B.mb+n*B.nb*ldb], ldb);
				}
			}

			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbk*mvbk]) \
							depend(inout:bkn[0:mvbk*nvbn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaLower, PlasmaNoTrans, PlasmaUnit,
							mvbk, nvbn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);
		}
    }

	// colunm first
	for(int n = 0; n < B.nt; n ++){
		for(int k = B.mt-1; k >= 0; k --){
			int mvbkn = plasma_tile_mview(B, k);
			int nvbkn = plasma_tile_nview(B, n);

			// trsm
			double *akk = A(k, k), *bkn = B(k, n);
			#pragma omp task depend(in:akk[0:mvbkn*mvbkn]) \
							depend(inout:bkn[0:mvbkn*nvbkn])
			plasma_core_dtrsm(PlasmaLeft, PlasmaUpper, PlasmaNoTrans, PlasmaNonUnit,
							mvbkn, nvbkn,
							1.0, &pA[k*A.mb+k*A.nb*lda], lda,
								 &pB[k*B.mb+n*B.nb*ldb], ldb);

			// gemm
			int nvak = plasma_tile_nview(A, k);
			for(int m = k-1; m >= 0; m --) {
				double *amk = A(m, k), *bkn = B(k, n), *bmn = B(m, n);

				#pragma omp task depend(in:amk[0:A.mb*nvak]) \
								depend(in:bkn[0:mvbkn*nvbkn]) \
								depend(inout:bmn[0:B.mb*nvbkn])
				{
				#ifdef LIKWID
					LIKWID_MARKER_START("demo");
				#endif
				#ifdef PAPI
					int EventSet = -1;
					trace_cache_start(&EventSet);
				#endif
				// #ifdef TRACE
				// 	trace_cpu_start();
				// #endif
				#ifdef TIME
					double time_cost,start,ops=2.0*B.mb*nvbkn*mvbkn,gflops;
					start = omp_get_wtime();
				#endif
				
					#ifdef TRACE
						trace_cpu_start();
					#endif
					if(__sync_bool_compare_and_swap(&flag_b_u[k+n*B.gmt], 0, 1)) {
						dgemm_oncopy(mvbkn, nvbkn, &pB[k*B.mb+n*B.nb*ldb], ldb, B_PACK(k, n));
						flag_b_u[k+n*B.gmt]++;
					}
					if(__sync_bool_compare_and_swap(&flag_a_trsm[m+k*A.gmt], 0, 1)) {
						dgemm_itcopy(mvbkn, B.mb, &pA[m*A.mb+k*A.nb*lda], lda, A_PACK(m, k));
						flag_a_trsm[m+k*A.gmt]++;
					}
					#ifdef TRACE
						trace_cpu_stop("Khaki");
						trace_label("Khaki", "PACK");
					#endif

					#ifdef TRACE
						trace_cpu_start();
					#endif
					while(flag_a_trsm[m+k*A.gmt] == 1 ||flag_b_u[k+n*B.gmt] == 1);
					#ifdef TRACE
						trace_cpu_stop("Pink");
						trace_label("Pink", "WAIT");
					#endif

					#ifdef TRACE
						trace_cpu_start();
					#endif
					dgemm_kernel(B.mb, nvbkn, mvbkn, -1.0, A_PACK(m, k), B_PACK(k, n), &pB[m*B.mb+n*B.nb*ldb], ldb);
					#ifdef TRACE
						trace_cpu_stop("Green");
						trace_label("Green", "MKERNEL");
					#endif

				#ifdef TIME
					time_cost = omp_get_wtime() - start;
					gflops = ops/time_cost/1.0e9;
					printf("m=%d,n=%d,k=%d,time_cost=%.2lf,ops=%.2lf,gflops,%.2lf\n",B.mb,nvbkn,mvbkn,time_cost,ops,gflops);
				#endif
				// #ifdef TRACE
				// 	trace_cpu_stop("LightSeaGreen");
				// 	trace_label("LightSeaGreen", "KERNEL");
				// #endif
				#ifdef PAPI
					trace_cache_stop(&EventSet, "KERNEL");
				#endif
				#ifdef LIKWID
					LIKWID_MARKER_STOP("demo");
				#endif
					// plasma_core_dgemm(
					// 	PlasmaNoTrans, PlasmaNoTrans,
					// 	B.mb, nvbkn, mvbkn,
					// 	-1.0, &pA[m*A.mb+k*A.nb*lda], lda,
					// 		  &pB[k*B.mb+n*B.nb*ldb], ldb,
					// 	1.0,  &pB[m*B.mb+n*B.nb*ldb], ldb);
				}
			}
		}
	}
}


#include <stdio.h>

int main( int argc, char** argv )
{
    int x = 1;
    printf( "hello, x=%d\n", x );
    return 0;
}

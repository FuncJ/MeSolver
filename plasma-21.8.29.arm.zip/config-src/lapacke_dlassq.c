
#if defined( MKL_ILP64 ) || defined( ILP64 )
    typedef long long myint;
#else
    typedef int myint;
#endif

#if defined( LOWERCASE )
    #define FORTRAN_NAME( lower, UPPER ) lower
#elif defined( UPPERCASE )
    #define FORTRAN_NAME( lower, UPPER ) UPPER
#else
    #define FORTRAN_NAME( lower, UPPER ) lower ## _
#endif

#ifdef __cplusplus
    #define EXTERN_C extern "C"
#else
    #define EXTERN_C
#endif

#include <stdio.h>

#ifdef HAVE_MKL
    #include <mkl_lapacke.h>
#else
    #include <lapacke.h>
#endif

#define dlassq FORTRAN_NAME( dlassq, DLASSQ )

//EXTERN_C
//void dlassq( const myint* n, const double* x, const myint* incx,
//             double* scale, double* sumsq );

int main( int argc, char** argv )
{
    int n = 3, incx = 1;
    double x[3] = { 1, 2, 2 };
    double scale, sumsq;
    double expect = 9;
    LAPACKE_dlassq_work( n, x, incx, &scale, &sumsq );
    //dlassq( &n, x, &incx, &scale, &sumsq );
    double result = sumsq*scale*scale;
    int okay = (result == expect);
    printf( "dlassq result %.2f, expect %.2f, %s\n",
            result, expect, (okay ? "ok" : "failed"));
    return ! okay;
}

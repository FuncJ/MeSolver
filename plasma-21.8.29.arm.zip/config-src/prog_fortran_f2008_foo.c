
#include <stdio.h>

void foo( int x )
{
    printf( "%s( %d )\n", __func__, x );
}

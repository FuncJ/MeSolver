# PLASMA is a software package provided by:
# University of Tennessee, US,
# University of Manchester, UK.

from config import *
